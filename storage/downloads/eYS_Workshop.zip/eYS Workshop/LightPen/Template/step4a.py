############################################
## Import OpenCV
import numpy
import cv2
# Initialize camera
cap = cv2.VideoCapture(1)
############################################

lower = numpy.array([0,0,200]) 
upper = numpy.array([30,10,255]) 

############################################
## Finding the point (LED)
def findPoint(img):
        global lower, upper
        ## Convert to HSV
        hsv = cv2.cvtColor (img, cv2.COLOR_BGR2HSV)

        ## Threshold the image
        mask = cv2.inRange(hsv, lower, upper)
        
        return mask

############################################
## Video Loop

while(1):
        
        ## Read the image
        ret, frame = cap.read()

        ## Do the processing
        output = findPoint(frame)
        cv2.imshow('original',frame)
        ## Show the image
        cv2.imshow('image', output)

        k = cv2.waitKey(1)

        ## End the video loop
        if k == ord('g'):
                lower = numpy.array([60, 100, 230]) 
                upper = numpy.array([75, 150, 255]) 
        if k == ord('r'):
                lower = numpy.array([0,0,200]) 
                upper = numpy.array([30,10,255])
        if k == ord('b'):
                lower = numpy.array([100, 10, 200]) 
                upper = numpy.array([120, 170, 255]) 
                
        if k == 27:  ## 27 - ASCII for escape key
                break
############################################

############################################
## Close and exit
# close camera
cap.release()
cv2.destroyAllWindows()
############################################
