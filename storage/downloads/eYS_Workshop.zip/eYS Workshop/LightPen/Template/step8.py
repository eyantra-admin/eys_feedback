############################################
## Import OpenCV
import numpy
import cv2
# Initialize camera
cap = cv2.VideoCapture(1)

#canvas = numpy.zeros((480,640,3), numpy.uint8)
############################################

############################################
## Finding the point (LED)
def findPoint(img):
        global oldPos

        ## Convert to HSV
        hsv = cv2.cvtColor (img, cv2.COLOR_BGR2HSV)

        ## Define thresholds
        lower = numpy.array([0,0,200]) 
        upper = numpy.array([30,10,255]) 

        ## Threshold the image
        mask = cv2.inRange(hsv, lower, upper)

        ## Find the blob of red
        contours, hierarchy = cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        #contours = []
        ## Default return value
        (cx,cy) = (0,0)
        
        ## Find blob with biggest area
        if len(contours)>0:
                maxA = 400
                maxC = []
                for cnt in contours:
                        area = cv2.contourArea(cnt)
                        if area>maxA:
                                maxC = cnt
                                maxA = area
                if maxC != []:
                        ## Find the center of that blob
                        M = cv2.moments(maxC)
                        if M['m00'] != 0:
                                cx = int(M['m10']/M['m00'])
                                cy = int(M['m01']/M['m00'])
        return mask, (cx,cy)

############################################
## Video Loop

while(1):
        ## Read the image
        ret, frame = cap.read()

        ## Do the processing
        mask,outxy = findPoint(frame)

        ## Draw the point returned
        cv2.circle(frame, outxy, 5, (0,0,255), 3)
        cv2.circle(frame, outxy, 20, (255,0,255), 3)
        cv2.circle(frame, outxy, 40, (0,255,255), 3)

        ## Show the image
        cv2.imshow('image', frame)

        ## End the video loop
        if cv2.waitKey(1) == 27:  ## 27 - ASCII for escape key
                break
############################################

############################################
## Close and exit
# close camera
cap.release()
cv2.destroyAllWindows()
############################################
