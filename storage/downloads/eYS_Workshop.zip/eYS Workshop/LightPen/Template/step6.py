############################################
## Import OpenCV
import numpy
import cv2
# Initialize camera
cap = cv2.VideoCapture(1)
############################################

############################################
## Finding the point (LED)
def findPoint(img):

        ## Convert to HSV
        hsv = cv2.cvtColor (img, cv2.COLOR_BGR2HSV)

        ## Define thresholds
        lower = numpy.array([0,0,200]) 
        upper = numpy.array([30,10,255]) 

        ## Threshold the image
        mask = cv2.inRange(hsv, lower, upper)

        ## Find the blob of red
        contours, hierarchy = cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

        ## Find blob with biggest area
        if len(contours)>0:
                maxA = 0
                maxC = []
                for cnt in contours:
                        area = cv2.contourArea(cnt)
                        if area>maxA:
                                maxC = cnt
                                maxA = area

        cv2.drawContours(img, contours, -1, (0,0,255), 3)
        
        return img

############################################
## Video Loop

while(1):
        
        ## Read the image
        ret, frame = cap.read()

        ## Do the processing
        output = findPoint(frame)

        ## Show the image
        cv2.imshow('image', output)

        ## End the video loop
        if cv2.waitKey(1) == 27:  ## 27 - ASCII for escape key
                break
############################################

############################################
## Close and exit
# close camera
cap.release()
cv2.destroyAllWindows()
############################################
