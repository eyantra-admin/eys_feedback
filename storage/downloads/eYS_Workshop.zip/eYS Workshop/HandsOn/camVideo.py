############################################
## Import OpenCV
import numpy
import cv2
# Initialize camera
cap = cv2.VideoCapture(1)
############################################

############################################
## Video Loop

while(1):

        
        ## Read the image
        ret, frame = cap.read()

        ## Do the processing

        ## Show the image
        cv2.imshow('image',frame)

        ## End the video loop
        if cv2.waitKey(1) == 27:  ## 27 - ASCII for escape key
                break
############################################

############################################
## Close and exit
# close camera
cap.release()
cv2.destroyAllWindows()
############################################
